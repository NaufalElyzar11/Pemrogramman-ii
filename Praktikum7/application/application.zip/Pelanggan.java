package application;

public class Pelanggan {
		private String pelanggan_id;
		private String nama;
		private String email;
		private int telepon;
		
		public Pelanggan(String id_penjualan, String nama, String email, int telepon) {
			this.pelanggan_id = id_penjualan;
			this.nama = nama;
			this.email = email;
			this.telepon = telepon;
		}
		
		public String getPelangganID() {
			return this.pelanggan_id;
		}
		
		public String getNama() {
			return this.nama;
		}
		
		public String getEmail() {
			return this.email;
		}
		
		public int getTelepon() {
			return this.telepon;
		}
	}
