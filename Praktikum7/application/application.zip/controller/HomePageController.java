package application.controller;

import application.Database;
import application.Buku;
import application.Pelanggan;
import application.Penjualan;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Date;
import javafx.beans.property.SimpleObjectProperty;


public class HomePageController {

    // Pelanggan
    @FXML
    private TableView<Pelanggan> tabelPelanggan;
    @FXML
    private TableColumn<Pelanggan, String> namaColumn;
    @FXML
    private TableColumn<Pelanggan, String> emailColumn;
    @FXML
    private TableColumn<Pelanggan, Integer> teleponColumn;
    @FXML
    private TextField namaField;
    @FXML
    private TextField emailField;
    @FXML
    private TextField teleponField;
    @FXML
    private Button buttonAddPelanggan, buttonEditPelanggan, buttonDeletePelanggan;
    private ObservableList<Pelanggan> pelangganList;

    // Buku
    @FXML
    private TableView<Buku> tabelBuku;
    @FXML
    private TableColumn<Buku, String> judulColumn;
    @FXML
    private TableColumn<Buku, String> penulisColumn;
    @FXML
    private TableColumn<Buku, Integer> hargaColumn;
    @FXML
    private TableColumn<Buku, Integer> stokColumn;
    @FXML
    private TextField judulField, penulisField, hargaField, stokField;
    @FXML
    private Button buttonAddBuku, buttonEditBuku, buttonDeleteBuku;
    private ObservableList<Buku> bukuList;

    // Penjualan
    @FXML
    private TableView<Penjualan> tabelPenjualan;
    @FXML
    private TableColumn<Penjualan, Integer> jumlahColumn;
    @FXML
    private TableColumn<Penjualan, Integer> totalHargaColumn;
    @FXML
    private TableColumn<Penjualan, Date> tanggalColumn;
    @FXML
    private TextField jumlahField, totalHargaField, tanggalField;
    @FXML
    private Button buttonAddPenjualan, buttonEditPenjualan, buttonDeletePenjualan;
    private ObservableList<Penjualan> penjualanList;
    
 // HomePageController.java

    @FXML
    private void handleAddPelanggan() {
        String pelanggan_id = "P" + (pelangganList.size() + 1); // Contoh ID pelanggan
        String nama = namaField.getText();
        String email = emailField.getText();
        int telepon = Integer.parseInt(teleponField.getText());

        try {
            Database.addPelanggan(pelanggan_id, nama, email, telepon);
            loadDataPelanggan(); // Refresh data
            clearPelangganFields(); // Clear input fields
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleEditPelanggan() {
        Pelanggan selectedPelanggan = tabelPelanggan.getSelectionModel().getSelectedItem();
        if (selectedPelanggan != null) {
            String pelanggan_id = selectedPelanggan.getPelangganID(); // Ambil ID pelanggan yang dipilih
            String nama = namaField.getText();
            String email = emailField.getText();
            int telepon = Integer.parseInt(teleponField.getText());

            try {
                Database.updatePelanggan(pelanggan_id, nama, email, telepon);
                loadDataPelanggan(); // Refresh data
                clearPelangganFields(); // Clear input fields
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @FXML
    private void handleDeletePelanggan() {
        Pelanggan selectedPelanggan = tabelPelanggan.getSelectionModel().getSelectedItem();
        if (selectedPelanggan != null) {
            String pelanggan_id = selectedPelanggan.getPelangganID(); // Ambil ID pelanggan yang dipilih

            try {
                Database.deletePelanggan(pelanggan_id);
                loadDataPelanggan(); // Refresh data
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    @FXML
    private void handleAddBuku() {
        String buku_id = "B" + (bukuList.size() + 1); // Contoh ID buku
        String judul = judulField.getText();
        String penulis = penulisField.getText();
        int harga = Integer.parseInt(hargaField.getText());
        int stok = Integer.parseInt(stokField.getText());

        try {
            Database.addBuku(buku_id, judul, penulis, harga, stok);
            loadDataBuku(); // Refresh data
            clearBukuFields(); // Clear input fields
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleEditBuku() {
        Buku selectedBuku = tabelBuku.getSelectionModel().getSelectedItem();
        if (selectedBuku != null) {
            String buku_id = selectedBuku.getBukuID(); // Ambil ID buku yang dipilih
            String judul = judulField.getText();
            String penulis = penulisField.getText();
            int harga = Integer.parseInt(hargaField.getText());
            int stok = Integer.parseInt(stokField.getText());

            try {
                Database.updateBuku(buku_id, judul, penulis, harga, stok);
                loadDataBuku(); // Refresh data
                clearBukuFields(); // Clear input fields
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @FXML
    private void handleDeleteBuku() {
        Buku selectedBuku = tabelBuku.getSelectionModel().getSelectedItem();
        if (selectedBuku != null) {
            String buku_id = selectedBuku.getBukuID(); // Ambil ID buku yang dipilih

            try {
                Database.deleteBuku(buku_id);
                loadDataBuku(); // Refresh data
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void clearBukuFields() {
        judulField.clear();
        penulisField.clear();
        hargaField.clear();
        stokField.clear();
    }

    @FXML
    private void handleAddPenjualan() {
        String penjualan_id = "J" + (penjualanList.size() + 1); // Contoh ID penjualan
        int jumlah = Integer.parseInt(jumlahField.getText());
        int total_harga = Integer.parseInt(totalHargaField.getText());
        Date tanggal = Date.valueOf(tanggalField.getText());
        String pelanggan_id = "P1"; // Ganti dengan ID pelanggan yang sesuai
        String buku_id = "B1"; // Ganti dengan ID buku yang sesuai

        try {
            Database.addPenjualan(penjualan_id, jumlah, total_harga, tanggal, pelanggan_id, buku_id);
            loadDataPenjualan(); // Refresh data
            clearPenjualanFields(); // Clear input fields
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleEditPenjualan() {
        Penjualan selectedPenjualan = tabelPenjualan.getSelectionModel().getSelectedItem();
        if (selectedPenjualan != null) {
            String penjualan_id = selectedPenjualan.getPenjualanID(); // Ambil ID penjualan yang dipilih
            int jumlah = Integer.parseInt(jumlahField.getText());
            int total_harga = Integer.parseInt(totalHargaField.getText());
            Date tanggal = Date.valueOf(tanggalField.getText());
            String pelanggan_id = "P1"; // Ganti dengan ID pelanggan yang sesuai
            String buku_id = "B1"; // Ganti dengan ID buku yang sesuai

            try {
                Database.updatePenjualan(penjualan_id, jumlah, total_harga, tanggal, pelanggan_id, buku_id);
                loadDataPenjualan(); // Refresh data
                clearPenjualanFields(); // Clear input fields
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @FXML
    private void handleDeletePenjualan() {
        Penjualan selectedPenjualan = tabelPenjualan.getSelectionModel().getSelectedItem();
        if (selectedPenjualan != null) {
            String penjualan_id = selectedPenjualan.getPenjualanID(); // Ambil ID penjualan yang dipilih

            try {
                Database.deletePenjualan(penjualan_id);
                loadDataPenjualan(); // Refresh data
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void clearPenjualanFields() {
        jumlahField.clear();
        totalHargaField.clear();
        tanggalField.clear();
    }
       

    private void clearPelangganFields() {
        namaField.clear();
        emailField.clear();
        teleponField.clear();
    }
    
    
    public void initialize() {
        initializePelanggan();
        initializeBuku();
        initializePenjualan();
    }

    private void initializePelanggan() {
        namaColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getNama()));
        emailColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getEmail()));
        teleponColumn.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getTelepon()).asObject());
        loadDataPelanggan();
    }

    private void initializeBuku() {
        judulColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getJudul()));
        penulisColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getPenulis()));
        hargaColumn.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getHarga()).asObject());
        stokColumn.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getStok()).asObject());
        loadDataBuku();
    }

    private void initializePenjualan() {
        jumlahColumn.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getJumlah()).asObject());
        totalHargaColumn.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getTotalHarga()).asObject());
        tanggalColumn.setCellValueFactory(cellData -> new SimpleObjectProperty<>(cellData.getValue().getTanggal()));
        loadDataPenjualan();
    }

    private void loadDataPelanggan() {
        pelangganList = FXCollections.observableArrayList();
        try (Connection conn = Database.connect();
             Statement stat = conn.createStatement();
             ResultSet rs = stat.executeQuery("SELECT * FROM pelanggan")) {
            while (rs.next()) {
                pelangganList.add(new Pelanggan(rs.getString("pelanggan_id"), rs.getString("nama"), rs.getString("email"), rs.getInt("telepon")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        tabelPelanggan.setItems(pelangganList);
    }

    private void loadDataBuku() {
        bukuList = FXCollections.observableArrayList();
        try (Connection conn = Database.connect();
             Statement stat = conn.createStatement();
             ResultSet rs = stat.executeQuery("SELECT * FROM buku")) {
            while (rs.next()) {
                bukuList.add(new Buku(rs.getString("buku_id"), rs.getString("judul"), rs.getString("penulis"), rs.getInt("harga"), rs.getInt("stok")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        tabelBuku.setItems(bukuList);
    }

    private void loadDataPenjualan() {
        penjualanList = FXCollections.observableArrayList();
        try (Connection conn = Database.connect();
             Statement stat = conn.createStatement();
             ResultSet rs = stat.executeQuery("SELECT * FROM penjualan")) {
            while (rs.next()) {
                penjualanList.add(new Penjualan(
                    rs.getString("pelanggan_id"), 
                    rs.getString("buku_id"),
                    rs.getString("penjualan_id"),
                    rs.getInt("jumlah"), 
                    rs.getInt("total_harga"), 
                    rs.getDate("tanggal")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        tabelPenjualan.setItems(penjualanList);
    }

    // Add, Edit, Delete handlers...
}
