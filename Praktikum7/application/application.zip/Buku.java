package application;

public class Buku {
	
	private String buku_id;
	private String judul;
	private String penulis;
	private int harga;
	private int stok;
	
	public Buku(String id_buku, String judul, String penulis, int harga, int stok) {
		this.buku_id = id_buku;
		this.judul = judul;
		this.penulis = penulis;
		this.harga = harga;
	}
	
	public String getBukuID() {
		return this.buku_id;
	}
	
	public String getJudul() {
		return this.judul;
	}
	
	public String getPenulis() {
		return this.penulis;
	}
	
	public int getHarga() {
		return this.harga;
	}
	
	public int getStok() {
		return this.stok;
	}
}
