package application;
import java.sql.Date;

public class Penjualan {
		private String pelanggan_id;
		private String buku_id;
		private String penjualan_id;
		private int jumlah;
		private int total_harga;
		private Date tanggal;
		
		public Penjualan(String id_pelanggan, String id_buku, String id_penjualan, int jumlah, int total, Date tanggal) {
			this.pelanggan_id = id_pelanggan;
			this.buku_id = id_buku;
			this.penjualan_id = id_penjualan;
			this.jumlah = jumlah;
			this.total_harga = total;
			this.tanggal = tanggal;
		}
		
		public String getPelangganID() {
			return this.pelanggan_id;
		}
		
		public String getBukuID() {
			return this.buku_id;
		}
		
		public String getPenjualanID() {
			return this.penjualan_id;
		}
		
		public int getJumlah() {
			return this.jumlah;
		}
		
		public int getTotalHarga() {
			return this.total_harga;
		}
		
		public Date getTanggal() {
			return this.tanggal;
		}
	}
